<?php
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/DepartmentManager.php';
require_once '../db/TimetableManager.php';

$internal = 0;
$sem = 0;
$Year = 0;
$count = 0;
$Temp = 0;
$TempArray = array();

session_start();
$id= $_SESSION['student'][0]['id'];
$sem= $_SESSION['student'][0]['student_sem'];

if (isset($_GET['internal'])) {
    $internal = $_GET['internal'];
}

// if (isset($_GET['semister'])) {
//     $sem = $_GET['semister'];
// }
if (isset($_GET['years'])) {
    $Year = $_GET['years'];
}

$Semister = array(1, 2, 3, 4, 5, 6);
$deptRid = 1;

$StudentId = 0;

$marks = TimetableManager::getTimeMarksForStudent($internal, $Year, $sem,$id);
$department = DepartmentManager::getDepartmentDetails($deptRid);
$AcademicYear = TimetableManager::AcademicYear();
?>

<html>
<?php require_once '../include/head.php'; ?>

<body>

    <?php require_once './student_left_nav.php'; ?>
    <?php require_once './student_top_bar.php'; ?>

    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
        <div class="row screen">
            <h4 class="p-2">Marks</h4>
        </div>
        <div class="row screen">
            <form action="" method="get">
                <div class="form-inline">
                    <label class="mr-1">Internal</label>
                    <select class="form-control-sm" id="internal" name="internal">
                        <option value="1" <?php $internal == 1 ? 'selected' : ''; ?>>1</option>
                        <option value="2" <?php $internal == 2 ? 'selected' : ''; ?>>2</option>
                        <option value="3" <?php $internal == 3 ? 'selected' : ''; ?>>3</option>
                    </select>

                    
                    <label class="mr-1 ml-1">Year</label>

                    <select class="form-control ml-1" id="years" name="years">
                        <?php foreach ($AcademicYear as $year) { ?>
                            <option value="<?php echo $year['year'] ?>" <?php $Year == $year['year'] ? 'selected' : ''; ?>><?php echo $year['year'] ?></option>
                        <?php  } ?>

                    </select>
                    <button class="btn btn-primary btn-sm ml-1">
                        View Marks
                    </button>
                </div>
            </form>
        </div>


        <?php if ($marks > 0) {
            $i = 0;
            foreach ($marks as $mark) {
                if ($StudentId == $mark['student_id']) {
        ?>
                    <tr>
                        <td><?php echo ++$i; ?></td>
                        <td><?php echo $mark['title'];  ?></td>
                        <td><?php echo $mark['code'];  ?></td>
                        <td><?php echo $mark['min_marks']; ?></td>
                        <td><?php echo $mark['max_marks']; ?></td>
                        <!--<td><?php echo $mark['min_marks'] + $mark['max_marks']; ?></td>-->
                        <td><?php echo $mark['marks']; ?></td>
                    </tr>
                    <?php $StudentId = $mark['student_id'] ?>

                <?php } else {
                    $count++;
                    $data = array(
                        'Count' => $count,
                        'email' => $mark['student_email']
                    );
                    array_push($TempArray, $data);

                ?>
                    <div class="print-area my-4  rounded-0">
                        <?php if ($internal > 0) { ?>
                            <div class=" mt-3" id="College<?php echo  $count; ?>">
                                <table class="table table-borderless table-sm">
                                    <tr>
                                        <td class="text-center">
                                            <strong><?php echo COLLEGE_Name?></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">
                                            <strong>Department of <?php echo $department['name']; ?></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">
                                            <strong>
                                                <?php
                                                if ($internal == 1) {
                                                    echo "First";
                                                } else if ($internal == 2) {
                                                    echo "Second";
                                                } else if ($internal == 3) {
                                                    echo "Third";
                                                }
                                                ?>
                                                Internal Marks
                                            </strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> <span class="ml-2 my-2"><b>Student Name: </b><?php echo  $mark['student_name']; ?></span>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                        <?php } ?>
                        <div class="mx-2 ">


                            <table class="table table-bordered table-sm" id="marksData<?php echo  $count; ?>">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Subject Name</th>
                                        <th>Subject code</th>
                                        <th>Min Marks</th>
                                        <th>Max Marks</th>
                                        <!--<th>Total Marks</th>-->
                                        <th>Obtained</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    ?>

                                    <tr>
                                        <td><?php echo ++$i; ?></td>
                                        <td><?php echo $mark['title']; ?></td>
                                        <td><?php echo $mark['code']; ?></td>
                                        <td><?php echo $mark['min_marks']; ?></td>
                                        <td><?php echo $mark['max_marks']; ?></td>
                                        <!--<td><?php echo $mark['min_marks'] + $mark['max_marks']; ?></td>-->
                                        <td><?php echo $mark['marks']; ?></td>
                                    </tr>
                                    <?php $StudentId = $mark['student_id'] ?>



                                <?php } ?>

                        </div>
                    <?php  }

                    ?>
                    </tbody>
                    </table>
                    </div>
                <?php }
            if ($i == 0) { ?>
                    <input type="hidden" value="<?php echo $i ?>" id="IdValue">
                    <table class="table table-bordered table-sm" id="marksData<?php echo  $count; ?>">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Subject Name</th>
                                <th>Subject code</th>
                                <th>Min Marks</th>
                                <th>Max Marks</th>
                                <!--<th>Total Marks</th>-->
                                <th>Obtained</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="100%" class="alert alert-danger text-center">
                                    No records...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                <?php }
                ?>

                <form id="SendTimeTableInMail" method="post" action="../actions/admin_actions.php"></form>
                <input type="hidden" value="SendInEmail" name="command">
                <!-- <div id="Spin" class="d-flex justify-content-center">
                    <div class="spinner-grow text-success" role="status">
                    </div>
                    <div class="spinner-grow text-danger" role="status">
                    </div>
                    <div class="spinner-grow text-warning" role="status">
                    </div>
                    <div class="spinner-grow text-info" role="status">
                    </div>
                </div> -->
               

    </main>

    <div class="filldiv" hidden></div>


    <?php require_once '../include/footer.php'; ?>
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>

    <script src="../static/js/office.js"></script>

</body>

</html>