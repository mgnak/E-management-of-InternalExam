<?php

session_start();

require_once '../include/config.php';
require_once '../include/util.php';
require_once './Response.php';
require_once './../db/DB.php';
require_once './../db/LoginManager.php';
require_once './../db/SessionManager.php';
require_once './../db/StaffManager.php';
require_once './../db/StudentManager.php';
require_once './../db/SubjectManager.php';
require_once './../db/TimetableManager.php';
require_once './../db/QuestionManager.php';
require_once '../vendor/autoload.php';
require_once '../mailer/mailer.php';
$response = new Response();

try {

    if (isset($_GET['command'])) {
        $command = $_GET['command'];
    } else if (isset($_POST['command'])) {
        $command = $_POST['command'];
    } else {
        throw new Exception("Invalid request!");
    }

    if ('saveStaff' == $command) {
        $staffRid = $_POST['staffRid'];
        $subjectName = $_POST['staffName'];
        $shortName = $_POST['shortName'];
        $subjectCode = $_POST['contact'];
        $emailId = $_POST['emailId'];
        $password = $_POST['password'];
        $department = $_POST['department'];
        $address = $_POST['address'];
        $isActive = isset($_POST['isActive']) ? $_POST['isActive'] : 0;
        $isHoD = isset($_POST['isHoD']) ? $_POST['isHoD'] : 0;

        $res = StaffManager::saveStaff($staffRid, $subjectName, $shortName, $subjectCode, $emailId, $password, $department, $address, $isHoD, $isActive);

        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went wrong...");
        }
    } else if ('staffDetails' == $command) {
        $staffRid = $_GET['staffRid'];
        $staff = StaffManager::getStaffDetails($staffRid);
        $response->success($staff);
    } else if ('saveSubject' == $command) {
        $subjectRid = $_POST['subjectRid'];
        $title = $_POST['title'];
        $code = $_POST['code'];
        $batch = $_POST['batch'];
        $minMarks = $_POST['minMarks'];
        $maxMarks = $_POST['maxMarks'];
        $isActive = isset($_POST['isActive']) ? $_POST['isActive'] : 0;

        $res = SubjectManager::saveSubject($subjectRid, $title, $code, $batch, $minMarks, $maxMarks, $isActive);

        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went wrong...");
        }
    } else if ('subjectDetails' == $command) {
        $subjectRid = $_GET['subjectRid'];
        $subject = SubjectManager::getSubjectDetails($subjectRid);
        $response->success($subject);
    } else if ('saveStudentsStrength' == $command) {
        $ssRid = $_POST['ssRid'];
        $academicYear = $_POST['academicYear'];
        $department = $_POST['department'];
        $totalStudents = $_POST['totalStudents'];
        $isActive = isset($_POST['isActive']) ? $_POST['isActive'] : 0;

        $res = StudentManager::saveStudentStrength($ssRid, $academicYear, $department, $totalStudents, $isActive);

        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went  wrong...");
        }
    } else if ('strengthDetails' == $command) {
        $strengthRid = $_GET['strengthRid'];
        $strength = StudentManager::getStudentStrengthDetails($strengthRid);
        $response->success($strength);
    } else if ('saveAllotment' == $command) {
        $allotmentRid = $_POST['allotmentRid'];
        $staff = $_POST['staff'];
        $subject = $_POST['subject'];
        $academicYear = $_POST['academicYear'];
        $department = $_POST['department'];

        $res = SubjectManager::saveAllotment($allotmentRid, $staff, $subject, $academicYear, $department);

        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went  wrong...");
        }
    } else if ('saveSession' == $command) {
        $sessionRid = $_POST['sessionRid'];
        $sessionNumber = $_POST['sessionNumber'];
        $sessionDate = $_POST['sessionDate'];
        $sessionTime = $_POST['sessionTime'];
        $remarks = $_POST['remarks'];
        $isActive = isset($_POST['isActive']) ? $_POST['isActive'] : 0;

        $res = SessionManager::saveSession($sessionRid, $sessionNumber, $sessionDate, $sessionTime, $remarks, $isActive);

        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went  wrong...");
        }
    } else if ('sessionDetails' == $command) {
        $sessionRid = $_GET['sessionRid'];
        $session = SessionManager::getSessionDetails($sessionRid);
        $response->success($session);
    } else if ('saveTimeTable' == $command) {
        $session = $_POST['session'];
        $semType = $_POST['semType'];
        $academicYear = $_POST['academicYear'];
        $internal = $_POST['internal'];
        $departments = $_POST['department'];
        $sems = $_POST['sem'];
        $subjects = $_POST['subject'];

        $res = TimetableManager::saveTimeTable($session, $semType, $academicYear, $internal, $departments, $sems, $subjects);

        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went wrong...");
        }
    } else if ('saveStaffDuty' == $command) {
        $semType = $_POST['semType'];
        $internal = $_POST['internal'];
        $academicYear = $_POST['academicYear'];

        $staffs = $_POST['staff'];
        $sessions = $_POST['session'];
        $roomno = $_POST['roomno'];

        $res = TimetableManager::saveDuty($semType, $internal, $academicYear, $staffs, $sessions, $roomno);

        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went wrong...");
        }
    } else if ('saveQuestions' == $command) {
        $subject = $_POST['subject'];
        $year = $_POST['year'];
        $internal = $_POST['internal'];
        $infoText = $_POST['infoText'];
        $questionNo = $_POST['questionNo'];
        $questionBody = $_POST['questionBody'];
        $questionMarks = $_POST['questionMarks'];
        // $questionLevel = $_POST['questionLevel'];
        $staffRid = $_POST['staffRid'];
        $deptRid = $_POST['deptRid'];

        $res = QuestionManager::saveQuestion(
            $subject,
            $year,
            $internal,
            $infoText,
            $questionNo,
            $questionBody,
            $questionMarks,
            $staffRid,
            $deptRid
        );

        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went wrong...");
        }
    } elseif ('saveStudent' == $command) {
        $studentName = $_POST['student_Name'];
        $gender = $_POST['gender'];
        $dateOfBirth = $_POST['dateOfBirth'];
        $contact = $_POST['contact'];
        $emailId = $_POST['emailId'];
        $semister = $_POST['semister'];
        $address = $_POST['address'];
        $department = $_POST['department'];
        $student_rollno = $_POST['student_rollno'];
        $id = 0;
        $phone = StudentManager::GetStudentByContact($contact,$student_rollno);
        $email = StudentManager::GetStudentByEmail($emailId);
        if (count($phone) > 0) {
            throw new Exception("Phone Number or Roll No already exist...");
        } elseif (count($email) > 0) {
            throw new Exception("Email Id already exist...");
        } else {
            $res = StudentManager::AddEditStudent($studentName, $gender, $dateOfBirth, $contact, $emailId, $semister, $address, $department, $id, $student_rollno);

            if ($res > 0) {
                $response->success("Successfully completed..");
            } else {
                throw new Exception("Something went wrong...");
            }
        }
    } elseif ('EditStudent' == $command) {
        $id = $_GET['id'];
        $res = StudentManager::GetStudentBYId($id);
        if ($res > 0) {
            $response->success($res);
        } else {
            throw new Exception("Something went wrong...");
        }
    } elseif ('UpdateStudent' == $command) {
        $studentName = $_POST['student_Name'];
        $gender = $_POST['gender'];
        $dateOfBirth = $_POST['dateOfBirth'];
        $contact = $_POST['contact'];
        $emailId = $_POST['emailId'];
        $semister = $_POST['semister'];
        $address = $_POST['address'];
        $department = $_POST['department'];
        $studentId = $_POST['studentId'];
        $student_rollno = $_POST['student_rollno'];

        $res = StudentManager::AddEditStudent($studentName, $gender, $dateOfBirth, $contact, $emailId, $semister, $address, $department, $studentId, $student_rollno);

        if ($res > 0) {
            $response->success("Successfully completed!");
            // header('Location:../staff/Student.php');
        } else {
            throw new Exception("Something went wrong...");
        }
    } elseif ('SaveMarks' == $command) {
        $marksData = $_POST["MarksData"];
        $res = StudentManager::SaveMarks($marksData);
        if ($res > 0) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went wrong...");
        }
    } elseif ('SentTimeTableInMail' == $command) {
        $ImageString = $_POST['content'];
        $semister = $_POST['semister'];
        $res = StudentManager::GetStudentBySem($semister);
        $is_send = false;
        $message = "Internal Exam Time Table";
        foreach ($res as $key => $value) {
            $is_send = sendMail("Time Table", $ImageString, $value['student_email'], $message);
        }
        if ($is_send) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went wrong...");
        }
    } elseif ('SentMarksInMail' == $command) {
        $myArray = json_decode($_POST['myArray'], true);
        $is_send = false;
        $message = "Internal Marks";
        foreach ($myArray as $key => $value) {
            $is_send = sendMail("Internal Marks Card", $value['Image'], $value['email'], $message);
        }
        if ($is_send) {
            $response->success("Successfully completed!");
        } else {
            throw new Exception("Something went wrong...");
        }
    } elseif ($command == "student_Register") {
        $contact = $_POST['contact'];
        $student_rollno = $_POST['username'];
        $password = $_POST['password'];
        $res = StudentManager::GetStudentByContact($contact, $student_rollno);
        if ($res > 0) {
            $update = StudentManager::UpdateStudent($contact, $password);
            if ($update > 0) {
                $response->success("Successfully completed!");
            } else {
                throw new Exception("Invalid Contact Number");
            }
        } else {
            throw new Exception("Invalid contact number or roll no...");
        }
    } elseif ($command == "studentLogin") {
        $student_rollno = $_GET['username'];
        $password = $_GET['password'];
        $Login = StudentManager::StudentLogin($student_rollno, $password);
        $count = count($Login);
        if ($count > 0) {
            $_SESSION['student'] = $Login;
            $response->success("Successfully Login!");
        } else {
            throw new Exception("Something went wrong...");
        }
    }
} catch (Exception $ex) {
    $response->error($ex->getMessage());
}

$response->writeResponse();
