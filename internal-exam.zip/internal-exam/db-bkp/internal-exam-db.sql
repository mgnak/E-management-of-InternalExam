/*
SQLyog Enterprise - MySQL GUI v8.12 
MySQL - 5.7.23-log : Database - internal_exam_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`internal_exam_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `internal_exam_db`;

/*Table structure for table `academic_year` */

DROP TABLE IF EXISTS `academic_year`;

CREATE TABLE `academic_year` (
  `ay_rid` int(11) NOT NULL AUTO_INCREMENT,
  `sem` tinyint(4) NOT NULL,
  `year` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  PRIMARY KEY (`ay_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `academic_year` */

insert  into `academic_year`(`ay_rid`,`sem`,`year`,`status`) values (1,1,2023,1),(2,3,2023,1),(3,5,2023,1),(4,2,2023,1),(5,4,2023,1),(6,6,2023,1);

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `dept_rid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  PRIMARY KEY (`dept_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `department` */

insert  into `department`(`dept_rid`,`name`,`status`) values (1,'BCA',1);

/*Table structure for table `marks` */

DROP TABLE IF EXISTS `marks`;

CREATE TABLE `marks` (
  `mark_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `subject_id` int(4) DEFAULT NULL,
  `student_id` int(4) DEFAULT NULL,
  `internal` int(1) DEFAULT NULL,
  `marks` int(2) DEFAULT NULL,
  `sem` int(2) DEFAULT NULL,
  `year` int(4) DEFAULT NULL,
  PRIMARY KEY (`mark_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;

/*Data for the table `marks` */

insert  into `marks`(`mark_id`,`subject_id`,`student_id`,`internal`,`marks`,`sem`,`year`) values (1,8,5,1,19,1,2023),(2,1,9,1,18,4,2023),(3,10,9,1,20,4,2023),(4,17,1,1,22,1,2023),(5,17,2,1,21,1,2023),(6,17,3,1,20,1,2023),(7,17,4,1,14,1,2023),(8,17,5,1,17,1,2023),(9,17,6,1,23,1,2023),(10,17,7,1,25,1,2023),(11,17,8,1,23,1,2023),(12,17,9,1,24,1,2023),(13,17,10,1,17,1,2023),(14,27,21,1,22,5,2023),(15,27,22,1,20,5,2023),(16,27,23,1,23,5,2023),(17,27,24,1,23,5,2023),(18,27,25,1,25,5,2023),(19,27,26,1,17,5,2023),(20,27,27,1,19,5,2023),(21,27,28,1,24,5,2023),(22,27,29,1,25,5,2023),(23,27,30,1,20,5,2023),(24,27,21,2,21,5,2023),(25,27,22,2,21,5,2023),(26,27,23,2,24,5,2023),(27,27,24,2,25,5,2023),(28,27,25,2,23,5,2023),(29,27,26,2,19,5,2023),(30,27,27,2,21,5,2023),(31,27,28,2,23,5,2023),(32,27,29,2,24,5,2023),(33,27,30,2,21,5,2023),(34,17,1,2,22,1,2023),(35,17,2,2,21,1,2023),(36,17,3,2,20,1,2023),(37,17,4,2,14,1,2023),(38,17,5,2,17,1,2023),(39,17,6,2,23,1,2023),(40,17,7,2,25,1,2023),(41,17,8,2,23,1,2023),(42,17,9,2,24,1,2023),(43,17,10,2,17,1,2023),(44,15,1,1,20,1,2023),(45,15,2,1,25,1,2023),(46,15,3,1,24,1,2023),(47,15,4,1,24,1,2023),(48,15,5,1,23,1,2023),(49,15,6,1,22,1,2023),(50,15,7,1,25,1,2023),(51,15,8,1,21,1,2023),(52,15,9,1,21,1,2023),(53,15,10,1,20,1,2023),(54,15,1,2,21,1,2023),(55,15,2,2,25,1,2023),(56,15,3,2,25,1,2023),(57,15,4,2,23,1,2023),(58,15,5,2,22,1,2023),(59,15,6,2,23,1,2023),(60,15,7,2,24,1,2023),(61,15,8,2,22,1,2023),(62,15,9,2,20,1,2023),(63,15,10,2,22,1,2023),(64,9,1,1,19,1,2023),(65,9,2,1,22,1,2023),(66,9,3,1,23,1,2023),(67,9,4,1,21,1,2023),(68,9,5,1,24,1,2023),(69,9,6,1,25,1,2023),(70,9,7,1,25,1,2023),(71,9,8,1,25,1,2023),(72,9,9,1,25,1,2023),(73,9,10,1,25,1,2023),(74,9,1,2,23,1,2023),(75,9,2,2,24,1,2023),(76,9,3,2,25,1,2023),(77,9,4,2,24,1,2023),(78,9,5,2,23,1,2023),(79,9,6,2,25,1,2023),(80,9,7,2,24,1,2023),(81,9,8,2,23,1,2023),(82,9,9,2,24,1,2023),(83,9,10,2,22,1,2023),(84,18,1,1,23,1,2023),(85,18,2,1,24,1,2023),(86,18,3,1,25,1,2023),(87,18,4,1,24,1,2023),(88,18,5,1,22,1,2023),(89,18,6,1,21,1,2023),(90,18,7,1,25,1,2023),(91,18,8,1,16,1,2023),(92,18,9,1,15,1,2023),(93,18,10,1,25,1,2023),(94,18,1,2,25,1,2023),(95,18,2,2,20,1,2023),(96,18,3,2,25,1,2023),(97,18,4,2,25,1,2023),(98,18,5,2,21,1,2023),(99,18,6,2,22,1,2023),(100,18,7,2,24,1,2023),(101,18,8,2,17,1,2023),(102,18,9,2,23,1,2023),(103,18,10,2,25,1,2023);

/*Table structure for table `question_detail` */

DROP TABLE IF EXISTS `question_detail`;

CREATE TABLE `question_detail` (
  `qd_rid` int(11) NOT NULL AUTO_INCREMENT,
  `qh_rid` int(11) DEFAULT NULL COMMENT 'rid from question_header table',
  `question_no` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question` text COLLATE utf8mb4_unicode_ci,
  `mark` float DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`qd_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `question_detail` */

insert  into `question_detail`(`qd_rid`,`qh_rid`,`question_no`,`question`,`mark`,`created_at`) values (1,1,'1','Distinguish a program and process.',2,'2023-07-12 15:58:12'),(2,1,'2','Define the term throughput and Response time.',2,'2023-07-12 15:59:06'),(3,1,'3','List any 4 services of Operating System.',2,'2023-07-12 15:59:49'),(4,1,'4','Explain wc command in Linux.',2,'2023-07-12 16:00:26'),(5,1,'5','Specify the purpose of cut command in Linux.',2,'2023-07-12 16:01:18'),(6,1,'6','Expalin Multiprogramming and Time sharing Systems.',5,'2023-07-12 16:02:16'),(7,1,'7','Define PCB. Explain the components with Diagram.',5,'2023-07-12 16:03:57'),(8,1,'8','Explain FCFS scheduling with an example.',5,'2023-07-12 16:05:26'),(9,1,'9','Explain any 5 directory oriented commands available in Linux.',5,'2023-07-12 16:06:40'),(10,2,'1','Define Deadlock.',2,'2023-07-12 16:11:10'),(11,2,'2','What is Sswapping?',2,'2023-07-12 16:11:38'),(12,2,'3','Expalin read Command with syntax.',2,'2023-07-12 16:12:19'),(13,2,'4','Write the use and syntax to add and delete a user in Linux.',2,'2023-07-12 16:13:14'),(14,2,'5','What is the Purpose of break command in Linux.',2,'2023-07-12 16:14:06'),(15,2,'6','Explain Paging with a neat diagram.',5,'2023-07-12 16:15:02'),(16,2,'7','Explain Swapping with a neat diagram.',5,'2023-07-12 16:15:35'),(17,2,'8','Write a short note on positional Parameters.',5,'2023-07-12 16:16:26'),(18,3,'1','Mentio  4 types of Applications can be developed in .NET framework.',2,'2023-07-12 16:36:20'),(19,3,'2','What do you mean by Intellisence? List any two.',2,'2023-07-12 16:37:17'),(20,3,'3','List any 4 data conversion functions.',2,'2023-07-12 16:37:57'),(21,3,'4','What are the two ways of writing comments in VB .NET .',2,'2023-07-12 16:38:53'),(22,3,'5','How to declare variable in VB? Give Example.',2,'2023-07-12 16:39:32'),(23,3,'6','Explain the different components of VB IDE.',5,'2023-07-12 16:40:30'),(24,3,'7','Exaplain all forms of if statement with Examples.',5,'2023-07-12 16:41:23'),(25,3,'8','Explain select case statement with suitable examples.',5,'2023-07-12 16:42:33'),(26,4,'a','Expand CURD, SQL.',2,'2023-07-12 16:46:06'),(27,4,'b','Define Normalisation.',2,'2023-07-12 16:46:39'),(28,4,'c','What is SAS?',2,'2023-07-12 16:47:05'),(29,4,'d','Define skewness and kurrtosis.',2,'2023-07-12 16:47:32'),(30,4,'e','List and explain any 2 apply functions with an example.',2,'2023-07-12 16:48:22'),(31,4,'1','List and explain the features of MySQL.',5,'2023-07-12 16:49:03'),(32,4,'2','Explain stem and leaf plot with an example',5,'2023-07-12 16:49:51'),(33,4,'3','Briefly explain SAS architecture with diagram.',5,'2023-07-12 16:50:31'),(34,5,'1','Define the term Computer Network.',2,'2023-07-12 17:18:20'),(35,5,'2','Differentiate between Analog and Digital Data.',2,'2023-07-12 17:18:59'),(36,5,'3','Define the term latency.',2,'2023-07-12 17:19:24'),(37,5,'4','Differentiate bandwidth and throughput.',2,'2023-07-12 17:20:04'),(38,5,'5','write the difference between circuit switched and packet switched Networks.',2,'2023-07-12 17:21:07'),(39,5,'6','Explain Mesh topology with neat diagram.',5,'2023-07-12 17:21:48'),(40,5,'7','Explain connection Oriented and Connectionless Service.',5,'2023-07-12 17:22:24'),(41,5,'8','Explain Bus topology with neat diagram and mention their advantages and disadvantages.',5,'2023-07-12 17:23:33'),(42,6,'1','Define software and software Engineering.',2,'2023-07-12 18:13:37'),(43,6,'2','Define Portability and Reusability.',2,'2023-07-12 18:14:10'),(44,6,'3','Define Product metrics and Process metrics.',2,'2023-07-12 18:14:48'),(45,6,'4','What are runaway projects?',2,'2023-07-12 18:15:18'),(46,6,'5','Define Software Process.',2,'2023-07-12 18:15:49'),(47,6,'6','Explain Software problems.',5,'2023-07-12 18:16:11'),(48,6,'7','Explain the various problems faced in Software engineering.',5,'2023-07-12 18:16:57'),(49,6,'8','Briefly explain the various characteristics of a software process.',5,'2023-07-12 18:17:44'),(50,7,'1','Mention the components of an srs?',2,'2023-07-12 20:07:56'),(51,7,'2','Mention the basic activities involved in requirement process.',2,'2023-07-12 20:08:45'),(52,7,'3','What is a Data Dictionary?',2,'2023-07-12 20:10:57'),(53,7,'4','Mention different types of modules in a structure chart?',2,'2023-07-12 20:11:35'),(54,7,'5','Define coupling.',2,'2023-07-12 20:12:13'),(55,7,'6','Explain Data Flow Diagram with example.',5,'2023-07-12 20:12:50'),(56,7,'7','Explain levels of cohesion',5,'2023-07-12 20:13:17'),(57,7,'8','Write a note on Logic/Algorithm design.',5,'2023-07-12 20:14:09'),(58,8,'a','Define EditText View in Ansdroid. List any two important XML attributes of it.',2,'2023-07-12 20:49:50'),(59,8,'b','Specify two ways of available to make Button to listen the click event.',2,'2023-07-12 20:50:38'),(60,8,'c','Differentiate ListView and Spinner.',2,'2023-07-12 20:51:20'),(61,8,'d','Differentiate Option menu and dContext menu.',2,'2023-07-12 20:52:03'),(62,8,'e','Define AutoTextCompleteView. Give XML code snippet that defines a AutoTextCompleteView.',2,'2023-07-12 20:53:18'),(63,8,'1','Explain TextView with any four notable XML attributes.',5,'2023-07-12 20:54:01'),(64,8,'2','Explain Button view with example XML code snippet to define a checkbox and implement listener to handle click event.',5,'2023-07-12 20:55:43'),(65,8,'3','Explain CheckBox view with example XML code snippet to define a checkbox and implement listener to handle click event.',5,'2023-07-12 20:56:45');

/*Table structure for table `question_header` */

DROP TABLE IF EXISTS `question_header`;

CREATE TABLE `question_header` (
  `qh_rid` int(11) NOT NULL AUTO_INCREMENT,
  `staff_rid` int(11) DEFAULT NULL,
  `subject_rid` int(11) DEFAULT NULL,
  `dept_rid` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `internal` int(11) DEFAULT NULL,
  `info_text` text COLLATE utf8mb4_unicode_ci COMMENT 'Ex: Please write answer to 4 questions out of 5',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`qh_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `question_header` */

insert  into `question_header`(`qh_rid`,`staff_rid`,`subject_rid`,`dept_rid`,`year`,`internal`,`info_text`,`created_at`) values (1,2,4,1,2023,1,'Answer All','2023-07-12 15:58:12'),(2,2,4,1,2023,2,'II Internal Eamination In OS & Linux','2023-07-12 16:11:10'),(3,11,11,1,2023,1,'1 Hour and 25 marks','2023-07-12 16:36:20'),(4,10,32,1,2023,2,'Paper for 25 marks and 1 hour','2023-07-12 16:46:06'),(5,1,25,1,2023,1,'Duration 1 hr and Maximum marks: 25','2023-07-12 17:18:20'),(6,4,13,1,2023,1,'Duration:1hr  and  Maximum Marks:25','2023-07-12 18:13:37'),(7,4,13,1,2023,2,'Duration:1 hr and Maximum Marks:25','2023-07-12 20:07:56'),(8,3,27,1,2023,2,'BCACAC337','2023-07-12 20:49:50');

/*Table structure for table `session` */

DROP TABLE IF EXISTS `session`;

CREATE TABLE `session` (
  `session_rid` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) DEFAULT NULL COMMENT 'session number',
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `remarks` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`session_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `session` */

insert  into `session`(`session_rid`,`number`,`date`,`time`,`remarks`,`status`,`created_at`,`updated_at`) values (1,1,'2023-05-24','09:00:00','First session',1,'2023-06-20 15:42:40','2023-07-12 08:07:23'),(2,2,'2023-05-24','11:00:00','Second session',1,'2023-06-20 15:43:04','2023-07-12 08:08:06'),(3,3,'2023-05-24','14:00:00','Third session',1,'2023-06-20 15:43:31','2023-07-12 08:08:15'),(4,4,'2023-06-29','09:15:00','',0,'2023-06-28 21:15:55','2023-07-03 17:37:47'),(5,4,'2023-05-25','09:00:00','',1,'2023-07-03 17:36:58','2023-07-12 08:11:03'),(6,5,'2023-05-25','11:00:00','',1,'2023-07-03 17:38:35','2023-07-12 08:11:14'),(7,6,'2023-05-25','14:00:00','',1,'2023-07-03 17:39:16','2023-07-12 08:11:39'),(8,7,'2023-05-26','09:00:00','',1,'2023-07-03 17:41:02','2023-07-12 08:10:26'),(9,8,'2023-05-26','11:00:00','',1,'2023-07-03 17:41:39','2023-07-12 08:10:41'),(10,9,'2023-05-26','14:00:00','',1,'2023-07-03 17:42:37','2023-07-12 08:10:51'),(11,1,'2023-07-03','09:00:00','',1,'2023-07-12 08:12:21',NULL),(12,2,'2023-07-03','11:00:00','',1,'2023-07-12 08:12:46',NULL),(13,3,'2023-07-03','14:00:00','',1,'2023-07-12 08:13:05','2023-07-12 08:13:46'),(14,4,'2023-07-04','09:00:00','',1,'2023-07-12 08:14:04',NULL),(15,5,'2023-07-04','11:00:00','',1,'2023-07-12 08:14:21',NULL),(16,6,'2023-07-04','14:00:00','',1,'2023-07-12 08:14:46',NULL),(17,7,'2023-07-05','09:00:00','',1,'2023-07-12 08:15:45',NULL),(18,8,'2023-07-05','11:00:00','',1,'2023-07-12 08:16:05',NULL),(19,9,'2023-07-05','14:00:00','',1,'2023-07-12 08:16:22',NULL),(20,1,'2023-01-02','09:00:00','',1,'2023-07-12 08:51:18',NULL),(21,2,'2023-01-02','11:00:00','',1,'2023-07-12 08:51:55',NULL),(22,3,'2023-01-02','14:00:00','',1,'2023-07-12 08:52:27','2023-07-12 08:53:17'),(23,4,'2023-01-03','09:00:00','',1,'2023-07-12 08:52:56','2023-07-12 08:53:31'),(24,5,'2023-01-03','11:00:00','',1,'2023-07-12 08:53:59',NULL),(25,6,'2023-01-03','14:00:00','',1,'2023-07-12 08:54:18',NULL),(26,1,'2023-02-21','09:00:00','',1,'2023-07-12 08:58:45',NULL),(27,2,'2023-02-21','11:00:00','',1,'2023-07-12 08:59:22',NULL),(28,3,'2023-02-21','14:00:00','',1,'2023-07-12 08:59:49',NULL),(29,4,'2023-02-22','09:00:00','',1,'2023-07-12 08:59:49','2023-07-12 09:00:16'),(30,5,'2023-02-22','11:00:00','',1,'2023-07-12 09:00:36',NULL),(31,6,'2023-02-22','14:00:00','',1,'2023-07-12 09:00:54',NULL);

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `staff_rid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_name` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(75) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dept_rid` int(11) DEFAULT NULL,
  `address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_hod` tinyint(4) DEFAULT '0' COMMENT '0 = no, 1 = yes',
  `status` tinyint(4) DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`staff_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `staff` */

insert  into `staff`(`staff_rid`,`name`,`short_name`,`contact`,`email`,`password`,`dept_rid`,`address`,`is_hod`,`status`,`created_at`,`updated_at`) values (1,'Prajwal K','PK','9876543210','prajwalk@gmail.com','1111',1,'Mangalore',0,1,NULL,'2023-06-30 11:55:38'),(2,'Khalandar Shareef','KH','8834567890','shareef@gmail.com','1234',1,'Karkala',0,1,'2023-06-20 15:22:07','2023-07-03 17:25:14'),(3,'Vinayachandra','VC','9876543210','admin@gmail.com','admin',1,'Puttur',1,1,NULL,'2023-07-03 17:19:37'),(4,'Sowmya','SW','7898685611','sowmya@gmail.com','sowmya',1,'Darbe',0,1,'2023-07-03 17:18:21',NULL),(8,'Neelam Kuttappa','NK','6545859734','neelamk@gmail.com','neelam',1,'Madilkeri',0,1,'2023-07-03 17:23:57',NULL),(9,'Chaithra T','CT','9123456788','chaithra@gmail.com','123456',1,'Maani',0,1,'2023-07-03 17:25:00','2023-07-12 11:05:48'),(10,'Rajeshwari M','RM','7766554433','rajeshwari@gmail.com','rajee',1,'mangalore',0,1,'2023-07-03 17:26:02',NULL),(11,'Geetha Poornima','GPo','6545342311','geethapoornima@gmail.com','geetha',1,'Perlampady',0,1,'2023-07-03 17:27:45',NULL),(12,'Ramesh K ','RK','7867950432','Rameshkpoojari@gmail.com','ramesh',1,'Panja',0,1,'2023-07-03 17:29:12',NULL);

/*Table structure for table `staff_duty` */

DROP TABLE IF EXISTS `staff_duty`;

CREATE TABLE `staff_duty` (
  `sd_rid` int(6) NOT NULL AUTO_INCREMENT,
  `year` int(4) DEFAULT NULL COMMENT 'academic year',
  `internal` int(2) DEFAULT NULL,
  `is_odd_sem` tinyint(2) DEFAULT NULL COMMENT '0 = no, 1 = yes',
  `session_rid` int(6) DEFAULT NULL,
  `staff_rid` int(6) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  `roomno` int(4) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`sd_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `staff_duty` */

insert  into `staff_duty`(`sd_rid`,`year`,`internal`,`is_odd_sem`,`session_rid`,`staff_rid`,`status`,`roomno`,`created_at`) values (9,2023,1,0,2,9,1,201,'2023-07-12 07:55:08'),(10,2023,1,0,3,11,1,201,'2023-07-12 07:55:36'),(11,2023,1,0,5,4,1,202,'2023-07-12 07:57:02'),(12,2023,1,0,6,10,1,202,'2023-07-12 07:57:02'),(13,2023,1,0,7,2,1,202,'2023-07-12 07:57:02'),(14,2023,1,0,8,12,1,203,'2023-07-12 07:58:09'),(16,2023,1,0,10,3,1,203,'2023-07-12 07:58:09'),(17,2023,1,0,1,3,1,202,'2023-07-12 07:59:44'),(19,2023,1,0,3,12,1,202,'2023-07-12 07:59:44'),(20,2023,1,0,5,1,1,203,'2023-07-12 08:01:18'),(21,2023,1,0,6,8,1,203,'2023-07-12 08:01:18'),(23,2023,1,0,8,2,1,204,'2023-07-12 08:02:59'),(24,2023,1,0,9,10,1,204,'2023-07-12 08:02:59'),(25,2023,1,0,10,4,1,204,'2023-07-12 08:02:59'),(26,2023,1,0,1,2,1,203,'2023-07-12 08:02:59'),(27,2023,1,0,2,10,1,203,'2023-07-12 08:43:41'),(28,2023,1,0,3,4,1,203,'2023-07-12 08:44:10'),(30,2023,2,0,12,9,1,201,'2023-07-12 08:49:26'),(31,2023,2,0,13,11,1,201,'2023-07-12 08:49:26'),(32,2023,2,0,14,4,1,201,'2023-07-12 08:49:26'),(33,2023,2,0,15,10,1,201,'2023-07-12 08:49:26'),(34,2023,2,0,16,2,1,201,'2023-07-12 08:49:26'),(36,2023,2,0,18,8,1,201,'2023-07-12 08:49:26'),(37,2023,2,0,19,1,1,201,'2023-07-12 08:49:26'),(38,2023,2,0,11,3,1,202,'2023-07-12 08:49:26'),(40,2023,2,0,13,12,1,202,'2023-07-12 08:49:26'),(41,2023,2,0,14,1,1,202,'2023-07-12 08:49:26'),(42,2023,2,0,15,8,1,202,'2023-07-12 08:49:26'),(44,2023,2,0,17,2,1,202,'2023-07-12 08:49:26'),(45,2023,2,0,18,10,1,202,'2023-07-12 08:49:26'),(46,2023,2,0,19,4,1,202,'2023-07-12 08:49:26'),(48,2023,1,1,21,9,1,205,'2023-07-12 09:04:20'),(49,2023,1,1,22,11,1,205,'2023-07-12 09:04:20'),(50,2023,1,1,23,4,1,206,'2023-07-12 09:04:20'),(51,2023,1,1,24,10,1,206,'2023-07-12 09:04:20'),(52,2023,1,1,25,2,1,206,'2023-07-12 09:04:20'),(54,2023,2,1,27,8,1,201,'2023-07-12 09:05:35'),(55,2023,2,1,28,1,1,201,'2023-07-12 09:05:35'),(56,2023,2,1,29,12,1,201,'2023-07-12 09:05:35'),(58,2023,2,1,31,3,1,201,'2023-07-12 09:05:35'),(59,2023,3,0,19,11,1,206,'2023-07-13 08:47:31'),(60,2023,3,0,9,11,1,206,'2023-07-13 08:47:31'),(61,2023,3,0,8,11,1,206,'2023-07-13 08:47:31');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_name` varchar(100) DEFAULT NULL,
  `student_gender` varchar(10) DEFAULT NULL,
  `student_rollno` int(11) DEFAULT NULL,
  `student_dob` varchar(50) DEFAULT NULL,
  `student_contact` varchar(10) DEFAULT NULL,
  `student_email` varchar(100) DEFAULT NULL,
  `student_sem` varchar(5) DEFAULT NULL,
  `student_address` text,
  `student_department` varchar(20) DEFAULT NULL,
  `student_username` varchar(20) DEFAULT 'null',
  `Student_password` varchar(20) DEFAULT 'null',
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`id`,`student_name`,`student_gender`,`student_rollno`,`student_dob`,`student_contact`,`student_email`,`student_sem`,`student_address`,`student_department`,`student_username`,`Student_password`,`status`) values (1,'A Isha','Female',21800,'2004-01-01','9481147401','isha@gmail.com','1','Darbe','1','null','ishaa',1),(2,'Ananya','Female',21801,'2004-03-12','9481147402','AnanyaP@gmail.com','1','panja','1','null','ananya',1),(3,'Aravind','Male',21802,'2004-06-12','9481147403','Aravind@gmail.com','1','Ballari','1','null','null',1),(4,'A Isha','Female',21803,'2004-10-22','9481147404','Isha@gmail.com','1','Kavu','1','null','null',1),(5,'Anjana','Female',21804,'2004-07-27','9481147405','Anju@gmail.com','1','Kadaba','1','null','anjana',1),(6,'Bhavana','Female',21805,'2004-02-28','9481147406','Bhavana@gmail.com','1','Mandya','1','null','null',1),(7,'bharath K','Male',21807,'2004-06-06','9481147405','Bharath@gmail.com','1','darbe','1','null','anjana',1),(8,'Bhuvan M','Male',21806,'2003-11-22','9481147407','bhuvan@gmail.com','1','Bellare','1','null','null',1),(9,'Shyam N','Male',21808,'2004-09-11','9481147408','parentshyam@gmail.com','1','Naraavi','1','null','null',1),(10,'Thanaz Aisha','Female',21809,'2004-08-09','9481147409','Aisha@gmail.com','1','Maani','1','null','null',1),(11,'Abdul T','Male',20800,'2003-03-13','9481147400','Abdul@gmail.com','3','Kumbra','1','null','null',1),(12,'Amith J','Male',20801,'2003-09-11','9481147421','Amith@gmail.com','3','Kavu','1','null','null',1),(13,'Anush K','Male',20802,'2003-04-23','9481147423','Anushh@gmail.com','3','Kumbra','1','null','null',1),(14,'Ashwin','Male',20803,'2003-07-14','9481147423','ashwin@gmail.com','3','Mitthur','1','null','null',1),(15,'Apoorva A','Female',20804,'2003-04-04','9481147433','Appi@gmail.com','3','Movvar, \r\nKasargod','1','null','null',1),(16,'Mohan P','Male',20805,'2003-05-05','9481147423','Hanuma@gmail.com','3','Mysore','1','null','null',1),(17,'Aathmika','Female',20806,'2003-07-31','9876564536','Athu@gmail.com','3','Kaikamba','1','null','null',1),(18,'Chaithali K','Female',20807,'2003-07-07','9481147429','Chaithali@gmail.com','3','Mavanji','1','null','null',1),(19,'Divya Suresh','Female',20809,'2003-09-09','9481147412','divyas@gmail.com','3','Maroli,\r\nDakshina Kannada','1','null','null',1),(20,'Samruddhi K','Female',20808,'2003-04-05','9481147444','samruddhi@gmail.com','3','Peral, \r\nSullia','1','null','null',1),(21,'Shalini M','Female',19800,'2002-08-21','9481147499','shalini@gmail.com','5','Shanti Nagar','1','null','null',1),(22,'Pavan L','Male',19801,'2002-09-08','9481147999','pavan@gmail.com','5','pernaje, kavu','1','null','pavan',1),(23,'Kaushik Kurunji','Male',19803,'2002-07-12','9481142222','shanthala@gmail.com','5','KushalNagar','1','null','null',1),(24,'Sharan U','Male',19804,'2002-06-04','9482213421','sharan@gmail.com','5','Mangalore, D.K','1','null','null',1),(25,'Swarna','Female',19805,'2002-08-27','9455147421','swarna@gmail.com','5','Swarga','1','null','null',1),(26,'Mallika Singh','Female',19806,'2002-07-13','9481147123','mallikasingh@gmail.com','5','Kalleri\r\nBelthangadi','1','null','null',1),(27,'Geethashree','Female',19807,'2002-02-11','9481147421','geethashree@gmail.com','5','Shringeri','1','null','null',1),(28,'Shravan P','Male',19808,'2002-07-05','9483327421','shravan@gmail.com','5','Nanthoor,\r\nMangalore','1','null','shravan',1),(29,'Shree Raksha','Female',19809,'2002-05-04','9481138712','rakshashree@gmail.com','5','kadaba, D.K','1','null','raksha',1),(30,'Shamanth V','Male',19802,'2002-05-09','9481238733','shamanth@gmail.com','5','Sithangoli,\r\nKasargod','1','null','null',1);

/*Table structure for table `student_strength` */

DROP TABLE IF EXISTS `student_strength`;

CREATE TABLE `student_strength` (
  `ss_rid` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) DEFAULT NULL COMMENT 'academic year',
  `sem` tinyint(4) DEFAULT NULL,
  `dept_rid` int(11) DEFAULT NULL,
  `total_students` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`ss_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `student_strength` */

insert  into `student_strength`(`ss_rid`,`year`,`sem`,`dept_rid`,`total_students`,`status`,`created_at`,`updated_at`) values (1,2023,1,1,10,1,'2023-06-20 15:23:27',NULL),(2,2023,3,1,10,1,'2023-06-20 15:23:38',NULL),(3,2023,5,1,10,1,'2023-06-20 15:23:46',NULL),(4,2023,4,1,10,0,'2023-07-12 18:01:49',NULL);

/*Table structure for table `subject` */

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `subject_rid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch` int(11) DEFAULT NULL,
  `max_marks` int(11) DEFAULT NULL,
  `min_marks` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`subject_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `subject` */

insert  into `subject`(`subject_rid`,`title`,`code`,`batch`,`max_marks`,`min_marks`,`status`,`created_at`,`updated_at`) values (1,'Java Programming','BCAC282',2023,25,9,1,'2023-06-20 15:24:37','2023-07-08 12:19:07'),(2,'Network Security and Management','BCAC382',2023,25,9,1,'2023-06-20 15:29:34','2023-07-02 11:04:03'),(3,'Database concepts and Oracle','BCAC183',2023,25,9,1,'2023-06-20 15:30:05','2023-07-02 10:43:48'),(4,'Operating Systems& Linux','BCAC231',2023,25,9,1,'2023-06-20 15:30:41','2023-07-02 11:10:02'),(5,'Python Programming','BCAC335',2023,25,9,1,'2023-07-02 10:42:05','2023-07-02 11:04:27'),(6,'E-Commerce','BCAC381',2023,25,9,1,'2023-07-02 11:05:55',NULL),(7,'Fundamentals of  Information  Technology','BCAC131',2023,25,9,1,'2023-07-02 11:06:51',NULL),(8,'Problem Solving using C','BCAC132',2023,25,9,1,'2023-07-02 11:07:23',NULL),(9,'Office Automation Lab','BCAP134',2023,25,9,1,'2023-07-02 11:08:02',NULL),(10,'Data Structures','BCAC232',2023,25,9,1,'2023-07-02 11:34:09',NULL),(11,'Visual Basic .NET  Programming','BCAC233',2023,25,9,1,'2023-07-02 11:34:48',NULL),(12,'Computer Graphics and  Animation','BCAC281',2023,25,9,1,'2023-07-02 12:00:21',NULL),(13,'Software Engineering','BCAC331',2023,25,9,1,'2023-07-02 12:01:17',NULL),(14,'Web Technology','BCAC334',2023,25,9,1,'2023-07-02 12:03:41',NULL),(15,'C Programming lab','BCAP135',2023,25,9,1,'2023-07-02 12:10:12','2023-07-12 10:46:30'),(16,'Java Lab','BCAP287',2023,25,9,1,'2023-07-02 12:16:21',NULL),(17,'Computer Organization','BCAC133',2023,25,9,1,'2023-07-12 09:11:30',NULL),(18,'Internet Basics&  HTML','BCACE136',2023,25,9,1,'2023-07-12 09:12:54','2023-07-12 09:18:07'),(19,'Operating Systems and Data  Structures lab','BCAP234',2023,25,9,1,'2023-07-12 09:13:44',NULL),(20,'Desktop Publishing','BCACE237',2023,25,9,1,'2023-07-12 09:14:54',NULL),(21,'Data Mining','BCAC283',2023,25,9,1,'2023-07-12 09:17:53',NULL),(22,' Artificial  Intelligence','BCACE188',2023,25,9,1,'2023-07-12 09:21:14',NULL),(23,'Computer Graphics and  AnimationLab','BCAP286',2023,25,9,1,'2023-07-12 09:29:35',NULL),(24,'E-Commerce','BCAOE289',2023,25,9,0,'2023-07-12 09:30:13','2023-07-12 09:50:14'),(25,'Computer &  Communication Networks','BCAC332',2023,25,9,1,'2023-07-12 09:47:07',NULL),(26,'Distributed Computing','BCAC333',2023,25,9,1,'2023-07-12 09:47:46',NULL),(27,'Android Application Development','BCAC337',2023,25,9,1,'2023-07-12 09:48:30',NULL),(28,'Web Applications Lab','BCAP339',2023,25,9,1,'2023-07-12 09:48:59',NULL),(29,'Python Programming Lab ','BCAP340',2023,25,9,1,'2023-07-12 09:49:24','2023-07-12 11:06:14'),(30,'Network Security &  Management','BCAC382',2023,25,9,0,'2023-07-12 09:50:55','2023-07-12 09:51:08'),(31,'Software Testing','BCAC383',2023,25,9,1,'2023-07-12 09:51:48',NULL),(32,'Programming for  Analytics','BCAC384',2023,25,9,1,'2023-07-12 09:52:31',NULL),(33,'Basic Mathematics','BCAC181',2023,25,9,1,'2023-07-12 10:05:56',NULL),(34,'Basic Mathematics','BCAC181',2023,25,9,0,'2023-07-12 10:05:56','2023-07-12 10:06:20'),(35,'Object Oriented  Programming using  C++','BCAC182',2023,25,9,1,'2023-07-12 10:06:55',NULL),(36,'DBMS Lab','BCAP185',2023,25,9,1,'2023-07-12 10:07:51',NULL),(37,'C++ Lab','BCAP184',2023,25,9,1,'2023-07-12 10:08:09',NULL),(38,'VB .NET lab','BCAP235',2023,25,9,1,'2023-07-12 10:29:33',NULL);

/*Table structure for table `subject_allotment` */

DROP TABLE IF EXISTS `subject_allotment`;

CREATE TABLE `subject_allotment` (
  `sa_rid` int(11) NOT NULL AUTO_INCREMENT,
  `staff_rid` int(11) DEFAULT NULL,
  `subject_rid` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL COMMENT 'academic year',
  `sem` tinyint(4) DEFAULT NULL,
  `dept_rid` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`sa_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `subject_allotment` */

insert  into `subject_allotment`(`sa_rid`,`staff_rid`,`subject_rid`,`year`,`sem`,`dept_rid`,`created_at`) values (14,6,7,2023,1,1,'2023-07-12 10:11:52'),(15,9,8,2023,1,1,'2023-07-12 10:12:02'),(16,11,17,2023,1,1,'2023-07-12 10:12:14'),(17,4,9,2023,1,1,'2023-07-12 10:12:29'),(18,11,15,2023,1,1,'2023-07-12 10:13:18'),(19,12,18,2023,1,1,'2023-07-12 10:13:40'),(20,11,33,2023,2,1,'2023-07-12 10:14:28'),(21,3,35,2023,2,1,'2023-07-12 10:14:52'),(22,6,3,2023,2,1,'2023-07-12 10:15:10'),(23,3,37,2023,2,1,'2023-07-12 10:15:51'),(24,4,36,2023,2,1,'2023-07-12 10:16:20'),(25,12,22,2023,2,1,'2023-07-12 10:26:11'),(26,2,4,2023,3,1,'2023-07-12 10:26:44'),(27,4,10,2023,3,1,'2023-07-12 10:26:59'),(28,11,11,2023,3,1,'2023-07-12 10:27:16'),(29,12,20,2023,3,1,'2023-07-12 10:27:35'),(30,9,38,2023,3,1,'2023-07-12 10:29:55'),(31,2,19,2023,3,1,'2023-07-12 10:30:55'),(32,10,12,2023,4,1,'2023-07-12 10:31:11'),(33,11,16,2023,4,1,'2023-07-12 10:31:27'),(34,3,1,2023,4,1,'2023-07-12 10:31:42'),(35,12,21,2023,4,1,'2023-07-12 10:32:11'),(36,10,23,2023,4,1,'2023-07-12 10:32:36'),(37,4,13,2023,5,1,'2023-07-12 10:33:06'),(38,1,25,2023,5,1,'2023-07-12 10:33:28'),(39,2,26,2023,5,1,'2023-07-12 10:33:59'),(40,10,14,2023,5,1,'2023-07-12 10:34:21'),(41,3,27,2023,5,1,'2023-07-12 10:35:03'),(42,11,5,2023,5,1,'2023-07-12 10:35:19'),(43,10,28,2023,5,1,'2023-07-12 10:36:00'),(44,1,29,2023,5,1,'2023-07-12 10:36:13'),(45,8,6,2023,6,1,'2023-07-12 10:43:03'),(46,2,31,2023,6,1,'2023-07-12 10:43:36'),(47,1,2,2023,6,1,'2023-07-12 10:44:00'),(48,10,32,2023,6,1,'2023-07-12 10:44:11'),(51,3,8,2023,1,1,'2023-07-12 10:51:30'),(52,3,10,2023,3,1,'2023-07-12 12:00:49');

/*Table structure for table `time_table` */

DROP TABLE IF EXISTS `time_table`;

CREATE TABLE `time_table` (
  `tt_rid` int(11) NOT NULL AUTO_INCREMENT,
  `session_rid` int(11) DEFAULT NULL,
  `is_odd_sem` tinyint(4) NOT NULL COMMENT '0 = no, 1 = yes',
  `year` int(11) DEFAULT NULL COMMENT 'academic year',
  `dept_rid` int(11) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `subject_rid` int(11) DEFAULT NULL,
  `internal` tinyint(4) DEFAULT '0' COMMENT '1, 2 or 3',
  `status` tinyint(4) DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`tt_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `time_table` */

insert  into `time_table`(`tt_rid`,`session_rid`,`is_odd_sem`,`year`,`dept_rid`,`sem`,`subject_rid`,`internal`,`status`,`created_at`,`updated_at`) values (1,20,1,2023,1,1,7,1,1,'2023-07-12 14:17:07',NULL),(2,20,1,2023,1,3,4,1,1,'2023-07-12 14:17:07',NULL),(3,20,1,2023,1,5,13,1,1,'2023-07-12 14:17:07',NULL),(4,26,1,2023,1,1,7,2,1,'2023-07-12 14:17:50',NULL),(5,26,1,2023,1,3,4,2,1,'2023-07-12 14:17:50',NULL),(6,26,1,2023,1,5,13,2,1,'2023-07-12 14:17:50',NULL),(7,21,1,2023,1,1,8,1,1,'2023-07-12 14:18:57',NULL),(8,21,1,2023,1,3,10,1,1,'2023-07-12 14:18:57',NULL),(9,21,1,2023,1,5,25,1,1,'2023-07-12 14:18:57',NULL),(10,22,1,2023,1,1,17,1,1,'2023-07-12 14:20:02',NULL),(11,22,1,2023,1,3,11,1,1,'2023-07-12 14:20:02',NULL),(12,22,1,2023,1,5,26,1,1,'2023-07-12 14:20:02',NULL),(13,23,1,2023,1,2,33,1,1,'2023-07-12 14:21:30',NULL),(14,23,1,2023,1,4,12,1,1,'2023-07-12 14:21:30',NULL),(15,23,1,2023,1,6,31,1,1,'2023-07-12 14:21:30',NULL),(16,24,1,2023,1,1,15,1,1,'2023-07-12 14:24:38',NULL),(17,24,1,2023,1,3,38,1,1,'2023-07-12 14:24:38',NULL),(18,24,1,2023,1,5,5,1,1,'2023-07-12 14:24:38',NULL),(19,27,1,2023,1,1,8,2,1,'2023-07-12 14:25:23',NULL),(20,27,1,2023,1,3,10,2,1,'2023-07-12 14:25:23',NULL),(21,27,1,2023,1,5,25,2,1,'2023-07-12 14:25:23',NULL),(22,28,1,2023,1,1,17,2,1,'2023-07-12 14:25:57',NULL),(23,28,1,2023,1,3,11,2,1,'2023-07-12 14:25:57',NULL),(24,28,1,2023,1,5,26,2,1,'2023-07-12 14:25:57',NULL),(25,29,1,2023,1,1,15,2,1,'2023-07-12 14:26:30',NULL),(26,29,1,2023,1,3,38,2,1,'2023-07-12 14:26:30',NULL),(27,29,1,2023,1,5,14,2,1,'2023-07-12 14:26:30',NULL),(28,1,0,2023,1,2,33,1,1,'2023-07-12 14:32:31',NULL),(29,1,0,2023,1,4,12,1,1,'2023-07-12 14:32:31',NULL),(30,1,0,2023,1,6,31,1,1,'2023-07-12 14:32:31',NULL),(31,11,0,2023,1,2,33,2,1,'2023-07-12 14:33:20',NULL),(32,11,0,2023,1,4,12,2,1,'2023-07-12 14:33:20',NULL),(33,11,0,2023,1,6,31,2,1,'2023-07-12 14:33:20',NULL),(34,2,0,2023,1,2,35,1,1,'2023-07-12 14:34:24',NULL),(35,2,0,2023,-1,4,1,1,1,'2023-07-12 14:34:24',NULL),(36,2,0,2023,-1,6,6,1,1,'2023-07-12 14:34:24',NULL),(37,12,0,2023,1,2,35,2,1,'2023-07-12 14:35:09',NULL),(38,12,0,2023,1,4,1,2,1,'2023-07-12 14:35:09',NULL),(39,12,0,2023,1,6,6,2,1,'2023-07-12 14:35:09',NULL),(40,3,0,2023,1,2,3,1,1,'2023-07-12 14:36:15',NULL),(41,3,0,2023,1,4,21,1,1,'2023-07-12 14:36:15',NULL),(42,3,0,2023,1,6,2,1,1,'2023-07-12 14:36:15',NULL),(43,13,0,2023,1,2,3,2,1,'2023-07-12 14:36:42',NULL),(44,13,0,2023,1,4,21,2,1,'2023-07-12 14:36:42',NULL),(45,13,0,2023,1,6,2,2,1,'2023-07-12 14:36:42',NULL),(46,5,0,2023,1,2,22,1,1,'2023-07-12 14:39:15',NULL),(47,5,0,2023,1,4,23,1,1,'2023-07-12 14:39:15',NULL),(48,5,0,2023,1,6,32,1,1,'2023-07-12 14:39:15',NULL),(49,14,0,2023,1,2,22,2,1,'2023-07-12 14:40:00',NULL),(50,14,0,2023,-1,4,23,2,1,'2023-07-12 14:40:00',NULL),(51,14,0,2023,-1,6,32,2,1,'2023-07-12 14:40:00',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
