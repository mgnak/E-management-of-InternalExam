<?php

class LoginManager
{

    public static function login($loginId, $password)
    {

//        if (ADMIN_LOGIN_ID == $loginId && ADMIN_PASSWORD == $password) {
//            return (object) array(
//                'is_admin' => true,
//                'name' => 'Admin'
//            );
//        }




        $sql = "SELECT * FROM staff"
            . " WHERE (contact = '$loginId' OR email = '$loginId')"
            . " AND password = '$password'"
            . " AND `status` = 1";

        $user = DB::selectOne($sql);

        if (!empty($user)) {
            return $user;
        } else {
            throw new Exception("Invalid login credentials...");
        }
    }
}
