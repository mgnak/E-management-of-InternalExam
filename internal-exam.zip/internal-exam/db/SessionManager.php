<?php

class SessionManager {

    public static function getSessions() {
        $sql = "SELECT *,"
                . " DATE_FORMAT(`date`, '%d %M %Y') AS formatted_date,"
                . " DATE_FORMAT(`time`, '%h:%i %p') AS formatted_time"
                . " FROM `session`"
                . " WHERE `status` = 1";
        return DB::selectAll($sql);
    }

    public static function getSessionDetails($sessionRid) {
        $sql = "SELECT *,"
                . "DATE_FORMAT(date, '%d/%m/%Y') AS display_date_format"
                . " FROM `session` WHERE session_rid = $sessionRid";
        return DB::selectOne($sql);
    }

    public static function saveSession($sessionRid, $number, $date, $time, $remarks, $isActive) {

        // from dd/mm/yyyy to yyyy-mm-dd
        $date = implode('-', array_reverse(explode('/', $date)));

        if ($sessionRid > 0) {
            $sql = "UPDATE `session` SET "
                    . "number = '$number', `date` = '$date', `time` = '$time', "
                    . "remarks = '$remarks', `status` = '$isActive', "
                    . "updated_at = NOW()"
                    . " WHERE session_rid = $sessionRid";
            return DB::update($sql);
        } else {
            $sql = "INSERT INTO `session`(number, `date`, `time`, remarks, `status`, created_at)"
                    . " VALUES('$number', '$date', '$time', '$remarks', '$isActive', NOW())";
            return DB::insertAndGetId($sql);
        }
    }

}
