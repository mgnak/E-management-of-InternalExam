<?php

class StaffManager {

    public static function saveStaff($staffRid, $staffName, $shortName, $contact, $emailId, $password, $department, $address, $isHoD, $isActive) {
        if ($staffRid > 0) {

            $sql = "UPDATE staff SET `name` = '$staffName', short_name = '$shortName', contact = '$contact', email = '$emailId', "
                    . "`password` = '$password', dept_rid = '$department', address = '$address',"
                    . " `status` = '$isActive', "
                    . "updated_at = NOW() WHERE staff_rid = $staffRid";
            return DB::update($sql);
        } else {

            if (self::isDuplicateContact($contact)) {
                throw new Exception("Duplicate contact number!");
            }

            if (self::isDuplicateEmail($emailId)) {
                throw new Exception("Duplicate email id!");
            }

            $sql = "INSERT INTO staff(`name`, short_name, contact, email, `password`, dept_rid, address, is_hod, `status`, created_at)"
                    . " VALUES('$staffName', '$shortName', '$contact', '$emailId', '$password', '$department', '$address', '$isHoD', '$isActive', NOW())";
            return DB::insertAndGetId($sql);
        }
    }

    public static function isDuplicateContact($contact) {
        $sql = "SELECT 1 FROM staff WHERE contact = '$contact'";
        $res = DB::selectOne($sql);
        return !empty($res);
    }

    public static function isDuplicateEmail($emailId) {
        $sql = "SELECT 1 FROM staff WHERE email = '$emailId'";
        $res = DB::selectOne($sql);
        return !empty($res);
    }

    public static function getStaffDetails($staffRid) {
        $sql = "SELECT * FROM staff WHERE staff_rid = $staffRid";
        return DB::selectOne($sql);
    }

    public static function getStaffs($deptRid = 0, $staffName = null, $contact = null) {
        $sql = "SELECT *,"
                . " s.name AS staff_name,"
                . " s.status AS staff_status,"
                . " d.name AS dept_name"
                . " FROM staff AS s"
                . " LEFT JOIN department AS d ON (s.dept_rid = d.dept_rid)"
                . " WHERE s.status = 1";

        if ($deptRid > 0) {
            $sql .= " AND s.dept_rid = '$deptRid'";
        }

        if (!empty($staffName)) {
            $staffName = trim($staffName);
            $sql .= " AND s.name LIKE '$staffName%'";
        }

        if (!empty($contact)) {
            $contact = trim($contact);
            $sql .= " AND s.contact = '$contact'";
        }

        $sql .= " ORDER BY s.status DESC, s.name ASC";
        return DB::selectAll($sql);
    }

    public static function getDutyListForStaff($staffRid, $deptRid, $isHod = false) {
        $sql = "SELECT *,"
                . " s.name AS staff_name,"
                . " DATE_FORMAT(`date`, '%d %M %Y') AS formatted_date,"
                . " DATE_FORMAT(`time`, '%h:%i %p') AS formatted_time"
                . " FROM staff_duty AS sd"
                . " JOIN `session` AS ses ON (sd.session_rid = ses.session_rid)"
                . " JOIN staff AS s ON (sd.staff_rid = s.staff_rid)"
                . " WHERE 1 = 1";

        if (!$isHod) {  // if not HoD, then get data based on staff rid
            $sql .= " AND sd.staff_rid = $staffRid";
        }

        if ($deptRid > 0) { // based on department rid
            $sql .= " AND s.dept_rid = $deptRid";
        }

        return DB::selectAll($sql);
    }

}
