<?php

class SubjectManager {

    public static function getSubjects($subjectName = null, $subjectCode = null) {
        $sql = "SELECT * FROM subject"
                . " WHERE status = 1";


        if (!empty($subjectName)) {
            $subjectName = trim($subjectName);
            $sql .= " AND title LIKE '$subjectName%'";
        }

        if (!empty($subjectCode)) {
            $subjectCode = trim($subjectCode);
            $sql .= " AND code = '$subjectCode'";
        }

        $sql .= " ORDER BY code, title";
        return DB::selectAll($sql);
    }

    public static function getSubjectDetails($subjectRid) {
        $sql = "SELECT * FROM subject WHERE subject_rid = $subjectRid";
        return DB::selectOne($sql);
    }

    public static function saveSubject($subjectRid, $title, $code, $batch, $minMarks, $maxMarks, $isActive) {
        if ($subjectRid > 0) {
            $sql = "UPDATE `subject` SET title = '$title', "
                    . "`code` = '$code', batch = '$batch', max_marks = '$maxMarks', min_marks = '$minMarks',"
                    . " `status` = '$isActive', updated_at = NOW()"
                    . " WHERE subject_rid = $subjectRid";
            return DB::update($sql);
        } else {
            $sql = "INSERT INTO `subject`(title, `code`, batch, max_marks, min_marks, `status`, created_at)"
                    . " VALUES('$title', '$code', '$batch', '$maxMarks', '$minMarks', '$isActive', NOW())";
            return DB::insertAndGetId($sql);
        }
    }

    public static function getAcademicYear($allSem = true) {
        $sql = "SELECT * FROM academic_year"
                . " WHERE status = 1";

        if (!$allSem) {
            $sql .= " LIMIT 1";
        }

        return DB::selectAll($sql);
    }

    public static function getAcademicYearDetails($ayRid) {
        $sql = "SELECT * FROM academic_year"
                . " WHERE status = 1 AND ay_rid = $ayRid";
        return DB::selectOne($sql);
    }

    public static function saveAllotment($allotmentRid, $staff, $subject, $academicYear, $department) {

        $ay = self::getAcademicYearDetails($academicYear);

        $year = $ay['year'];
        $sem = $ay['sem'];

        if (self::isAlreadyAlloted($staff, $subject, $year, $sem, $department)) {
            throw new Exception("Already alloted");
        }

        $sql = "INSERT INTO subject_allotment(staff_rid, subject_rid, `year`, sem, dept_rid, created_at)"
                . " VALUES('$staff', '$subject', '$year', '$sem', '$department', NOW())";

        return DB::insertAndGetId($sql);
    }

    public static function getSubjectAllotments() {
        $sql = "SELECT *,"
                . " st.name AS staff_name,"
                . " d.name AS dept_name"
                . " FROM subject_allotment AS sa"
                . " JOIN subject AS su ON (sa.subject_rid = su.subject_rid)"
                . " JOIN staff AS st ON (sa.staff_rid = st.staff_rid)"
                . " JOIN department AS d ON (sa.dept_rid = d.dept_rid)";
        return DB::selectAll($sql);
    }

    public static function getAllotedSubjectsForStaff($staffRid) {
        $sql = "SELECT * FROM subject_allotment AS sa"
                . " JOIN `subject` AS sub ON (sa.subject_rid = sub.subject_rid)"
                . " WHERE sa.staff_rid = $staffRid";
        return DB::selectAll($sql);
    }

    public static function isAlreadyAlloted($staff, $subject, $year, $sem, $department) {
        $sql = "SELECT 1 FROM subject_allotment"
                . " WHERE staff_rid = $staff"
                . " AND subject_rid = $subject"
                . " AND `year` = $year"
                . " AND sem = $sem"
                . " AND dept_rid = $department";
        $res = DB::selectOne($sql);
        return !empty($res);
    }

}
