<?php

require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/QuestionManager.php';
require_once './TablePdf.php';

$quesions = QuestionManager::getQuestionsPaperForAdmin(2019, 1, 1, 1);

$html = 'You can now easily print text mixing different styles: <b>bold</b>, <i>italic</i>,
<u>underlined</u>, or <b><i><u>all at once</u></i></b>!<br><br>You can also insert links on
text, such as <a href="http://www.fpdf.org">www.fpdf.org</a>, or on an image: click on the logo.';

$a = array();

foreach ($quesions as $q) {
    $d = array(
        $q['question_no'],
        $q['question'],
        $q['mark'],
        $q['level'],
    );
    array_push($a, $d);
}


$pdf = new TablePdf();
// Column headings
$header = array('Country', 'Capital', 'Area (sq km)', 'Pop. (thousands)');
// Data loading
$data = $pdf->LoadData('countries.txt');
$pdf->SetFont('Arial', '', 14);
$pdf->AddPage();
$pdf->BasicTable($header, $data);
$pdf->AddPage();
$pdf->ImprovedTable($header, $data);
$pdf->AddPage();
$pdf->FancyTable($header, $data);
$pdf->Output();
