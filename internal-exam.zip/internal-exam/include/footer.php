<script src="../static/js/jquery.min.js"></script>
<script src="../static/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-printThis/1.15.0/printThis.min.js"></script>
