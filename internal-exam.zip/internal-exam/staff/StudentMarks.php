<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/SubjectManager.php';
require_once '../db/StudentManager.php';


$allotedSubjects = SubjectManager::getAllotedSubjectsForStaff($staffRid);
?>
<html>
<?php require_once '../include/head.php'; ?>

<body>

    <?php require_once './staff_left_nav.php'; ?>

    <div class="container-fluid  ms-5 my-5">
        <div class="row">

            <?php require_once './staff_top_bar.php'; ?>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="row">
                    <h4 class="p-2">Add Marks</h4>
                </div>



                <div class="card ml-5 rounded-0 w-50 mt-3">
                    <div class="card-body mt-3">
                        <div class="form-group mx-3">
                            <label for="exampleFormControlInput1" class="form-label text2"><b>Select Subject</b></label>

                            <select class="form-control" id="semister" name="semister" onchange="GetStudents(this.value)">
                                <option selected value="-1">--Subjects--</option>
                                <?php foreach ($allotedSubjects as $sub) { ?>
                                    <option value="<?php echo $sub['sem'] ?>,<?php echo $sub['subject_rid'] ?>,<?php echo $sub['year'] ?>"><?php echo $sub['title'] ?></option>
                                <?php  } ?>

                            </select>

                        </div>
                        <div class="mt-2" id="myDIV">

                        </div>
                    </div>
                </div>






            </main>
        </div>
    </div>
    <?php require_once '../include/footer.php'; ?>
    <script src="../static/js/Student.js"></script>


</body>

</html>