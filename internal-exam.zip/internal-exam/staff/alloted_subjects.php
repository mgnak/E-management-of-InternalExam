<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/SubjectManager.php';

$allotedSubjects = SubjectManager::getAllotedSubjectsForStaff($staffRid);
?>

<html>
    <?php require_once '../include/head.php'; ?>
    <body>

        <?php require_once './staff_left_nav.php'; ?>

        <div class="container-fluid">
            <div class="row">

                <?php require_once './staff_top_bar.php'; ?>

                <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                    <div class="row">
                        <h4 class="p-2">Alloted Subjects</h4>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-bordered table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Year</th>
                                        <th>Sem</th>
                                        <th>Code</th>
                                        <th>Subject</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($allotedSubjects as $as) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td><?php echo $as['year']; ?></td>
                                            <td><?php echo $as['sem']; ?></td>
                                            <td><?php echo $as['code']; ?></td>
                                            <td><?php echo $as['title']; ?></td>
                                        </tr>
                                        <?php
                                    }
                                    if ($i == 0) {
                                        ?>
                                        <tr>
                                            <td colspan="100%" class="alert alert-danger text-center">
                                                No records...
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <?php require_once '../include/footer.php'; ?>
    </body>
</html>