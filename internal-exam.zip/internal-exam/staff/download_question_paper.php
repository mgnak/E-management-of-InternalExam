<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/DepartmentManager.php';
require_once '../db/StaffManager.php';
require_once '../db/SubjectManager.php';
require_once '../db/QuestionManager.php';

$departments = DepartmentManager::getDepartments();
$staffs = StaffManager::getStaffs();
$academicYears = SubjectManager::getAcademicYear(false);
$subjects = SubjectManager::getSubjects();

$year = 0;
$department = 0;
$subject = 0;
$internal = 0;

$quesions = array();

if (isset($_GET['year']) && isset($_GET['department']) && isset($_GET['subject']) && isset($_GET['internal'])) {
    $year = $_GET['year'];
    $department = $_GET['department'];
    $subject = $_GET['subject'];
    $internal = $_GET['internal'];

    $quesions = QuestionManager::getQuestionsPaperForAdmin($year, $department, $subject, $internal);
    
    $subjectdetails= SubjectManager::getSubjectDetails($subject);
    
    
    
    
}
?>

<html>
<?php require_once '../include/head.php'; ?>

<body>

    <?php require_once './staff_left_nav.php'; ?>

    <div class="container-fluid">
        <div class="row" >

            <?php require_once './staff_top_bar.php'; ?>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="row">
                    <h4 class="p-2">Question Paper</h4>
                </div>
                <div class="row justify-content-end mb-2">
                    <form class="form-inline" onsubmit="return validateViewQuestionForm()">
                        <select class="form-control mr-1" id="year" name="year">
                            <option value="-1">--Select Year--</option>
                            <?php foreach ($academicYears as $ay) { ?>
                                <option value="<?php echo $ay['year']; ?>">
                                    <?php echo $ay['year']; ?>
                                </option>
                            <?php } ?>
                        </select>
                        <select class="form-control mr-1" id="department" name="department">
                            <option value="-1">--Select Department--</option>
                            <?php foreach ($departments as $department) { ?>
                                <option value="<?php echo $department['dept_rid'] ?>">
                                    <?php echo $department['name']; ?>
                                </option>
                            <?php } ?>
                        </select>
                        <select class="form-control mr-1" id="subject" name="subject">
                            <option value="-1">--Select Subject--</option>
                            <?php foreach ($subjects as $subject) { ?>
                                <option value="<?php echo $subject['subject_rid']; ?>">
                                    <?php echo $subject['title']; ?>
                                </option>
                            <?php } ?>
                        </select>
                        <select class="form-control mr-1" id="internal" name="internal">
                            <option value="-1">--Select Internal--</option>
                            <?php for ($i = 1; $i <= 3; $i++) { ?>
                                <option value="<?php echo $i; ?>">
                                    <?php echo $i; ?>
                                </option>
                            <?php } ?>
                        </select>
                        <button class="btn btn-primary mr-1" type="submit">
                            View
                        </button>
                    </form>
                </div>
                <div class="print-area" id="printContent">
                    <div>
                    <?php if ($internal > 0) { ?>
                        <div class="row">
                            <table class="table table-borderless table-sm">
                                <tr>
                                    <td class="text-center">
                                        <strong><?php echo COLLEGE_Name ?></strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center">
                                        <strong>Department of <?php echo 'BCA' ?></strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center">
                                        <strong>
                                            <?php
                                            if ($internal == 1) {
                                                echo "I";
                                            } else if ($internal == 2) {
                                                echo "II";
                                            } else if ($internal == 3) {
                                                echo "III";
                                            }
                                            ?>
                                            Internal Examination
                                        </strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left">
                                        <strong class="ml-5">
                                            <?php 
                                                     echo 'Subject Name : '.$subjectdetails["title"];
                                            ?>
                                        </strong>
                                         
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php } ?>
                    <div class="row" id="">
                        <div class="col-md-12">
                            <table class="table table-borderless table-sm table-striped" id="myTable">
                                <thead>
                                    <tr>
                                        <th class="w-10">Q. No</th>
                                        <th>Question</th>
                                        <th class="w-10">Marks</th>
                                        <!--<th class="w-10">Level</th>-->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($quesions as $q) {
                                    ?>
                                        <tr>
                                            <td><?php echo $q['question_no']; ?></td>
                                            <td><?php echo $q['question']; ?></td>
                                            <td><?php echo $q['mark']; ?></td>
                                            <!--<td><?php echo $q['level']; ?></td>-->
                                        </tr>
                                    <?php }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div class="d-flex justify-content-center">
            <button class="btn btn-primary" id="PrintQuestionPaper">Print</button>
        </div>
    </div>


    <?php require_once '../include/footer.php'; ?>

    <script src="../static/js/question.js"></script>
</body>

</html>