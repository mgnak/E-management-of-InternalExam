<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/SessionManager.php';

$sessions = SessionManager::getSessions();
?>

<html>
    <?php require_once '../include/head.php'; ?>
    <body>

        <?php require_once './staff_left_nav.php'; ?>

        <div class="container-fluid">
            <div class="row">

                <?php require_once './staff_top_bar.php'; ?>

                <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                    <div class="row">
                        <h4 class="p-2">Sessions</h4>
                    </div>
                    <div class="row justify-content-end mb-2">
                        <button id="btnAddSession"
                                class="btn btn-primary">
                            Add Session
                        </button>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-bordered table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Session Number</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($sessions as $session) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td class="text-right"><?php echo $session['number']; ?></td>
                                            <td><?php echo $session['formatted_date']; ?></td>
                                            <td><?php echo $session['formatted_time']; ?></td>
                                            <td>
                                                <a href="#"
                                                   onclick="getSessionDetails('<?php echo $session['session_rid']; ?>')">
                                                    Edit
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    if ($i == 0) {
                                        ?>
                                        <tr>
                                            <td colspan="100%" class="alert alert-danger text-center">
                                                No records...
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- add/update session modal -->
        <div id="modalAddUpdateSession" class="modal fade" tabindex="-1" role="dialog"
             data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="addUpdateSessionTitle" class="modal-title">Add Session</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="formAddUpdateSession" action="../actions/admin_actions.php" method="post">

                            <input type="hidden" name="command" id="command" value="saveSession"/>
                            <input type="hidden" name="sessionRid" id="sessionRid" value="0"/>

                            <div class="form-group">
                                <input type="number" class="form-control" name="sessionNumber" id="sessionNumber"
                                       placeholder="Session Number" autocomplete="off"
                                       min="1" max="100"/>
                            </div>

                            <div class="form-group">
                                <input type="date" class="form-control" name="sessionDate" id="sessionDate"
                                       placeholder="Date" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="time" class="form-control" name="sessionTime" id="sessionTime"
                                       placeholder="Time" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <textarea class="form-control" id="remarks" name="remarks"
                                          placeholder="Remarks (Optional)"></textarea>
                            </div>

                            <div class="form-group">
                                <input type="checkbox" id="isActive" name="isActive"
                                       value="1" checked="checked">
                                <label for="isActive">is active?</label>
                            </div>

                            <div class="form-group text-right">
                                <button type="submit"
                                        id="btnSaveInternalSession" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once '../include/footer.php'; ?>
        <script src="../static/js/internal_session.js"></script>
    </body>
</html>