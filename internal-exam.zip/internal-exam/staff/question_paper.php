<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/SubjectManager.php';

$academicYears = SubjectManager::getAcademicYear(false);
$subjects = SubjectManager::getAllotedSubjectsForStaff($staffRid);
?>

<html>
    <?php require_once '../include/head.php'; ?>
    <body>

        <?php require_once './staff_left_nav.php'; ?>

        <div class="container-fluid">
            <div class="row">

                <?php require_once './staff_top_bar.php'; ?>

                <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                    <div class="row">
                        <h4 class="p-2">Question Paper</h4>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <form action="../actions/admin_actions.php" id="formQuestionPaper" method="post">

                                        <input type="hidden" name="command" value="saveQuestions">
                                        <input type="hidden" name="staffRid" value="<?php echo $staffRid; ?>"> <!-- from session -->
                                        <input type="hidden" name="deptRid" value="<?php echo $deptRid; ?>"> <!-- from session -->

                                        <div class="row">
                                            <div class="col-md-4">
                                                <select class="form-control" id="subject" name="subject">
                                                    <option value="-1">--Select Subject--</option>
                                                    <?php foreach ($subjects as $subject) { ?>
                                                        <option value="<?php echo $subject['subject_rid']; ?>">
                                                            <?php echo $subject['title']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            
                                            <div class="col-md-4">
                                                <select class="form-control" id="year" name="year">
                                                    <option value="-1">--Select Year--</option>
                                                    <?php foreach ($academicYears as $ay) { ?>
                                                        <option value="<?php echo $ay['year']; ?>">
                                                            <?php echo $ay['year']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <select class="form-control" id="internal" name="internal">
                                                    <option value="-1">--Select Internal--</option>
                                                    <?php for ($i = 1; $i <= 3; $i++) { ?>
                                                        <option value="<?php echo $i; ?>">
                                                            <?php echo $i; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group mt-1">
                                            <input type="text" class="form-control" id="infoText" name="infoText"
                                                   placeholder="Info Text" autocomplete="off"/>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-inline">
                                                <label class="mr-4">Question No.</label>
                                                <input type="text" class="form-control" id="questionNo" name="questionNo"
                                                       autocomplete="off"/>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-inline">
                                                <label class="mr-4">Question Body</label>
                                                <input type="text" class="form-control w-75" id="questionBody" name="questionBody"
                                                       autocomplete="off"/>
                                            </div>
                                        </div>
                                        <div class="form-group mt-1">
                                            <div class="form-inline">
                                                <label class="mr-4">Question Marks</label>
                                                <input type="text" class="form-control" id="questionMarks" name="questionMarks"
                                                       autocomplete="off"/>
                                            </div>
                                        </div>
                                        <!--<div class="form-group mt-1">
                                            <div class="form-inline">
                                                <label class="mr-4">Cognitive Level</label>
                                                <select class="form-control" id="questionLevel" name="questionLevel">
                                                    <option value="-1">--Select Level--</option>
                                                    <option value="A">Apply (A)</option>
                                                    <option value="R">Remember (R)</option>
                                                    <option value="U">Understand (U)</option>
                                                </select>
                                            </div>
                                        </div>-->
                                        <div class="form-group text-center">
                                            <button id="btnSaveQuestion" class="btn btn-primary">
                                                Save
                                            </button>
                                        </div>
                                    </form>
                                    <br>
                                    <table id="tblQuestion" class="table table-bordered table-sm">
                                        <thead>
                                            <tr>
                                                <th colspan="100%">
                                                    Questions
                                                </th>
                                            </tr>
                                            <tr>
                                                <th class="w-10">Q. No.</th>
                                                <th>Question</th>
                                                <th class="w-10">Marks</th>
                                                <!--<th class="w-10">Level</th>-->
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <?php require_once '../include/footer.php'; ?>
        <script src="../static/js/question.js"></script>
    </body>
</html>