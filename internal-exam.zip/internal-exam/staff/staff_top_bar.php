<nav class="navbar navbar-light fixed-top bg-white flex-md-nowrap p-0 shadow">
    <?php if ($isHoD) {
        $NavName = "HOD";
    } else {
        $NavName = "Staff";
    } ?>
    <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"><b><?php echo $NavName; ?></b></a>
    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
    </ul>
</nav>