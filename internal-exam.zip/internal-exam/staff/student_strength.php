<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/DepartmentManager.php';
require_once '../db/StudentManager.php';
require_once '../db/SubjectManager.php';

$departments = DepartmentManager::getDepartments();
$academicYears = SubjectManager::getAcademicYear();
$strengthList = StudentManager::getStudentsStrength();
?>

<html>
    <?php require_once '../include/head.php'; ?>
    <body>

        <?php require_once './staff_left_nav.php'; ?>

        <div class="container-fluid">
            <div class="row">

                <?php require_once './staff_top_bar.php'; ?>

                <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                    <div class="row">
                        <h4 class="p-2">Students Strength</h4>
                    </div>
                    <div class="row justify-content-end mb-2">
                        <button id="btnAddStudentStrength"
                                class="btn btn-primary">
                            Add Students Strength
                        </button>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-bordered table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Department</th>
                                        <th>Year</th>
                                        <th>Sem</th>
                                        <th>Total Students</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($strengthList as $ss) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td><?php echo $ss['dept_name']; ?></td>
                                            <td><?php echo $ss['year']; ?></td>
                                            <td><?php echo $ss['sem']; ?></td>
                                            <td><?php echo $ss['total_students']; ?></td>
                                            <td>
                                                <a href="#"
                                                   onclick="getStrengthDetails('<?php echo $ss['ss_rid']; ?>')">
                                                    Edit
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    if ($i == 0) {
                                        ?>
                                        <tr>
                                            <td colspan="100%" class="alert alert-danger text-center">
                                                No records...
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- add/update subject modal -->
        <div id="modalAddUpdateStudentsStrength" class="modal fade" tabindex="-1" role="dialog"
             data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="addUpdateStudentsStrengthTitle" class="modal-title">Add Students Strength</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="formAddUpdateStudentsStrength" action="../actions/admin_actions.php" method="post">

                            <input type="hidden" name="command" id="command" value="saveStudentsStrength"/>
                            <input type="hidden" name="ssRid" id="ssRid" value="0"/>
                            <input type="hidden" name="department" id="department" value="<?php echo $deptRid; ?>"/>

                            <div class="form-group">
                                <select class="form-control" id="academicYear" name="academicYear">
                                    <option value="-1">--Select Academic Year--</option>
                                    <?php foreach ($academicYears as $ay) { ?>
                                        <option value="<?php echo $ay['ay_rid']; ?>">
                                            <?php echo $ay['year'] . ' [ Sem ' . $ay['sem'] . ']'; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <input type="number" class="form-control" name="totalStudents" id="totalStudents"
                                       placeholder="Total Students" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="checkbox" name="isActive" id="isActive"
                                       checked="checked" value="1"/>
                                <label for="isActive">is active?</label>
                            </div>

                            <div class="form-group text-right">
                                <button type="submit"
                                        id="btnSaveStudentsStrength" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once '../include/footer.php'; ?>
        <script src="../static/js/student_strength.js"></script>
    </body>
</html>