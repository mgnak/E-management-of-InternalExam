<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/SubjectManager.php';

$subjectName = "";
$subjectCode = "";

if (isset($_GET['searchSubjectName'])) {
    $subjectName = $_GET['searchSubjectName'];
}

if (isset($_GET['searchSubjectCode'])) {
    $subjectCode = $_GET['searchSubjectCode'];
}

$subjects = SubjectManager::getSubjects($subjectName, $subjectCode);
?>

<html>
    <?php require_once '../include/head.php'; ?>
    <body>

        <?php require_once './staff_left_nav.php'; ?>

        <div class="container-fluid">
            <div class="row">

                <?php require_once './staff_top_bar.php'; ?>

                <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                    <div class="row">
                        <h4 class="p-2">Subjects</h4>
                    </div>
                    <div class="row justify-content-end mb-2">
                        <form class="form-inline">
                            <label class="mr-2">Filter by</label>
                            <input type="text" class="form-control mr-1"
                                   name="searchSubjectName" placeholder="Name" autocomplete="off">
                            <input type="text" class="form-control mr-1"
                                   name="searchSubjectCode" placeholder="Code" autocomplete="off">
                            <button class="btn btn-primary mr-1" type="submit">
                                View
                            </button>
                            <button id="btnAddSubject"
                                    class="btn btn-primary">
                                Add Subject
                            </button>
                        </form>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-bordered table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Code</th>
                                        <th>Batch</th>
                                        <th class="text-center">Min Marks</th>
                                        <th class="text-center">Max Marks</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($subjects as $subject) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td><?php echo $subject['title']; ?></td>
                                            <td><?php echo $subject['code']; ?></td>
                                            <td><?php echo $subject['batch']; ?></td>
                                            <td class="text-center"><?php echo $subject['min_marks']; ?></td>
                                            <td class="text-center"><?php echo $subject['max_marks']; ?></td>
                                            <td><?php echo $subject['status'] == 1 ? 'ACTIVE' : 'INACTIVE'; ?></td>
                                            <td>
                                                <a href="#"
                                                   onclick="getSubjectDetails('<?php echo $subject['subject_rid']; ?>')">
                                                    Edit
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    if ($i == 0) {
                                        ?>
                                        <tr>
                                            <td colspan="100%" class="alert alert-danger text-center">
                                                No records...
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- add/update subject modal -->
        <div id="modalAddUpdateSubject" class="modal fade" tabindex="-1" role="dialog"
             data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="addUpdateSubjectTitle" class="modal-title">Add Subject</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="formAddUpdateSubject" action="../actions/admin_actions.php" method="post">

                            <input type="hidden" name="command" id="command" value="saveSubject"/>
                            <input type="hidden" name="subjectRid" id="subjectRid" value="0"/>

                            <div class="form-group">
                                <input type="text" class="form-control" name="title" id="title"
                                       placeholder="Title" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" name="code" id="code"
                                       placeholder="Code" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" name="batch" id="batch"
                                       placeholder="Batch (Ex: 2019, 2020)" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="number" class="form-control" name="minMarks" id="minMarks"
                                       placeholder="Min Marks" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="number" class="form-control" name="maxMarks" id="maxMarks"
                                       placeholder="Max Marks" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="checkbox" name="isActive" id="isActive"
                                       checked="checked" value="1"/>
                                <label for="isActive">is active?</label>
                            </div>

                            <div class="form-group text-right">
                                <button type="submit"
                                        id="btnSaveSubject" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once '../include/footer.php'; ?>
        <script src="../static/js/subject.js"></script>
    </body>
</html>