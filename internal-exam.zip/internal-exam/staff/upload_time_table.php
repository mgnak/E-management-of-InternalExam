<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/DepartmentManager.php';
require_once '../db/SessionManager.php';
require_once '../db/SubjectManager.php';

$departments = DepartmentManager::getDepartments();
$sessions = SessionManager::getSessions();
$academicYears = SubjectManager::getAcademicYear(false);
$subjects = SubjectManager::getSubjects();
?>

<html>
<?php require_once '../include/head.php'; ?>

<body>

    <?php require_once './staff_left_nav.php'; ?>

    <div class="container-fluid">
        <div class="row">

            <?php require_once './staff_top_bar.php'; ?>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="row">
                    <h4 class="p-2">Time Table</h4>
                </div>
                <form id="formTimeTable" action="../actions/admin_actions.php" method="post">

                    <input type="hidden" name="command" value="saveTimeTable" />

                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-3">
                                    <select class="form-control" id="session" name="session">
                                        <option value="-1">--Select Session--</option>
                                        <?php foreach ($sessions as $session) { ?>
                                            <option value="<?php echo $session['session_rid']; ?>">
                                                <?php
                                                $dateTime = $session['formatted_date'] . ' ' . $session['formatted_time'];
                                                echo $session['number'] . ' (' . $dateTime . ')';
                                                ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-control" id="semType" name="semType">
                                        <option value="-1">--Sem Type--</option>
                                        <option value="0">Even Sem</option>
                                        <option value="1">Odd Sem</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-control" id="academicYear" name="academicYear">
                                        <option value="-1">--Academic Year--</option>
                                        <?php foreach ($academicYears as $ay) { ?>
                                            <option value="<?php echo $ay['year']; ?>">
                                                <?php echo $ay['year']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-control" id="internal" name="internal">
                                        <option value="-1">--Select Internal--</option>
                                        <?php for ($i = 1; $i <= 3; $i++) { ?>
                                            <option value="<?php echo $i; ?>">
                                                <?php echo $i; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="selectionRow">
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-4">
                                        <select class="form-control" id="department" name="department[]" required>
                                            <option value="-1">--Select Branch--</option>
                                            <?php foreach ($departments as $department) { ?>
                                                <option value="<?php echo $department['dept_rid']; ?>">
                                                    <?php echo $department['name']; ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <input type="hidden" id="sem" name="sem[]">
                                    <!--<div class="col-md-2">-->
<!--                                        <select class="form-control" id="sem" name="sem[]" required>
                                            <option value="-1">--Select Sem--</option>
                                            <?php for ($sem = 1; $sem <= 6; $sem++) { ?>
                                                <option value="<?php echo $sem; ?>">
                                                    <?php echo $sem; ?>
                                                </option>
                                            <?php } ?>
                                        </select>-->
                                    <!--</div>-->
                                    <div class="col-md-4">
                                        <select class="form-control" id="subject" name="subject[]" required>
                                            <option value="-1">--Select Subject--</option>
                                            <?php foreach ($subjects as $subject) { ?>
                                                <option value="<?php echo $subject['subject_rid']; ?>">
                                                    <?php echo $subject['title']; ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <!-- <button id="btnRemoveNewRow" type="button" class="btn btn-warning" onclick="removeRow();">
                                            Remove Row
                                        </button> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="tempRow"></div>
                    <div class="row justify-content-center mt-4 mb-4">
                        <div class="col-md-1">
                            <button id="btnSaveTimeTable" type="submit" class="btn btn-primary">
                                Save
                            </button>
                        </div>
                        <div class="col-md-2">

                            <button id="btnAddNewRow" class="btn btn-warning">
                                Add Row
                            </button>
                        </div>

                    </div>
                </form>
            </main>
        </div>
    </div>

    <?php require_once '../include/footer.php'; ?>
    <script src="../static/js/time_table.js"></script>
</body>

</html>