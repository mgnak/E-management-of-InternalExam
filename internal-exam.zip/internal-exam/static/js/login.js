$(function () {

    $('#btnLogin').click(function (evt) {
        evt.preventDefault();

        var loginId = $('#loginId').val();
        var password = $('#password').val();

        if (loginId === "") {
            alert("Please enter login id...");
            return false;
        }

        if (password === "") {
            alert("Please enter password...");
            return false;
        }

        $.ajax({
            url: $('#formLogin').prop('action'),
            type: $('#formLogin').prop('method'),
            data: $('#formLogin').serialize(),
            success: function (data, textStatus, jqXHR) {

                console.log(data);
                if (data.success) {

                    if (data.body.admin) {
                        $('#formAdminLoginRedirect').submit();
                    } else if (data.body.office) { 
                        $('#formOfficeLoginRedirect').submit();
                    }
                    else {
                        $('#formStaffLoginRedirect').submit();
                    }

                } else {
                    alert(data.error);
                }

            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });

});