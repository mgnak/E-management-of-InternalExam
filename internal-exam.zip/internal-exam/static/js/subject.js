$(function () {

    $('#btnAddSubject').click(function (evt) {
        evt.preventDefault();
        $('#formAddUpdateSubject')[0].reset();
        $('#addUpdateSubjectTitle').text('Add Subject');
        $('#modalAddUpdateSubject').modal('show');
    });

    $('#btnNewAllotment').click(function (evt) {
        evt.preventDefault();
        $('#formNewSubjectAllotment')[0].reset();
        $('#addUpdateSubjectAllotmentTitle').text('Add New Allotment');
        $('#modalSubjectAllotment').modal('show');
    });

    // new subject
    $('#btnSaveSubject').click(function (evt) {
        evt.preventDefault();

        var title = $('#title').val();
        var code = $('#code').val();
        var batch = $('#batch').val();
        var minMarks = $('#minMarks').val();
        var maxMarks = $('#maxMarks').val();

        if (title === "") {
            alert("Please enter title");
            return false;
        }

        if (code === "") {
            alert("Please enter subject code");
            return false;
        }

        if (batch === "") {
            alert("Please enter batch");
            return false;
        }

        if (minMarks === "" || isNaN(minMarks) || minMarks === 0) {
            alert("Invalid min marks");
            return false;
        }

        if (maxMarks === "" || isNaN(maxMarks) || maxMarks === 0) {
            alert("Invalid min marks");
            return false;
        }

        $.ajax({
            url: $('#formAddUpdateSubject').prop('action'),
            type: $('#formAddUpdateSubject').prop('method'),
            data: $('#formAddUpdateSubject').serialize(),
            success: function (data, textStatus, jqXHR) {
                if (data.success) {
                    alert(data.body);
                    location.reload();
                } else {
                    alert(data.error);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });

    // subject allotment
    $('#btnSaveAllotment').click(function (evt) {
        evt.preventDefault();

        var staff = $('#staff').val();
        var subject = $('#subject').val();
        var academicYear = $('#academicYear').val();
        var department = $('#department').val();

        if (staff === "-1") {
            alert("Please select staff");
            return false;
        }

        if (subject === "-1") {
            alert("Please select subject");
            return false;
        }

        if (academicYear === "-1") {
            alert("Please select academic year");
            return false;
        }

        if (department === "-1") {
            alert("Please select department");
            return false;
        }

        $.ajax({
            url: $('#formNewSubjectAllotment').prop('action'),
            type: $('#formNewSubjectAllotment').prop('method'),
            data: $('#formNewSubjectAllotment').serialize(),
            success: function (data, textStatus, jqXHR) {
                if (data.success) {
                    alert(data.body);
                    location.reload();
                } else {
                    alert(data.error);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });
});

function getSubjectDetails(subjectRid) {
    if (subjectRid) {
        $.ajax({
            url: '../actions/admin_actions.php',
            type: 'GET',
            data: {
                command: 'subjectDetails',
                subjectRid: subjectRid
            },
            success: function (data, textStatus, jqXHR) {
                if (data.success) {

                    var subject = data.body;

                    $('#addUpdateSubjectTitle').text('Update Subject');
                    $('#subjectRid').val(subject.subject_rid);
                    $('#title').val(subject.title);
                    $('#code').val(subject.code);
                    $('#batch').val(subject.batch);
                    $('#minMarks').val(subject.min_marks);
                    $('#maxMarks').val(subject.max_marks);
//                    $('#isActive').text(subject.status);

                    $('#modalAddUpdateSubject').modal('show');

                } else {
                    alert(data.body);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    }
}