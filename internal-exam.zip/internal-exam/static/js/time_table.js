var rowCount = 1;

$(function () {

    // print time table
    $('#btnPrint').click(function (evt) {
        evt.preventDefault();
        window.print();
    });

    // create new row
    $('#btnAddNewRow').click(function (evt) {
        evt.preventDefault();

        rowCount++;

        var content = $('#selectionRow').clone().prop('id', 'selectionRow' + rowCount);
        $('#tempRow').append(content);

    });


    $('#btnSaveTimeTable').click(function (evt) {
        evt.preventDefault();

        if (!confirm("Are you sure want to submit? \nThis action cannot be undone")) {
            return false;
        }

        $.ajax({
            url: $('#formTimeTable').prop('action'),
            type: $('#formTimeTable').prop('method'),
            data: $('#formTimeTable').serialize(),
            success: function (data, textStatus, jqXHR) {

                if (data.success) {
                    alert(data.body);
                    location.reload();
                } else {
                    alert(data.error);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });
});

function objectifyForm(formArray) {
    var array = {};
    for (var i = 0; i < formArray.length; i++) {
        array[formArray[i]['name']] = formArray[i]['value'];
    }
    //    return array;

    console.log(array);
}


function removeRow(){

    rowCount--;
    $('#selectionRow'+ rowCount).html('');
}
